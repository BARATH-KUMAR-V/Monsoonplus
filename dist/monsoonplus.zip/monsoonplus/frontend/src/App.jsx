import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router-dom';
import Shell from '@/components/Shell';
import { ErrorState, Loading } from '@/components/ui';
import { useStore } from '@/data/store';

// Code-split the heavier pages so the first paint on a phone stays quick.
const Overview = lazy(() => import('@/pages/Overview'));
const SmartTrip = lazy(() => import('@/pages/SmartTrip'));
const LiveMap = lazy(() => import('@/pages/LiveMap'));
const Forecast = lazy(() => import('@/pages/Forecast'));
const EventReplay = lazy(() => import('@/pages/EventReplay'));
const ModelLab = lazy(() => import('@/pages/ModelLab'));
const DataSystem = lazy(() => import('@/pages/DataSystem'));

function NotFound() {
  return (
    <ErrorState title="Page not found">
      That route does not exist. Use the navigation on the left.
    </ErrorState>
  );
}

export default function App() {
  const { status, error } = useStore();

  return (
    <Shell>
      {status === 'loading' && <Loading label="Loading model data" rows={4} />}

      {status === 'error' && (
        <ErrorState title="Could not load the model data" onRetry={() => window.location.reload()}>
          {error}. The app expects <code>public/data/predictions_synthetic_chennai.json</code> to
          exist. Run <code>python -m ml.export.export_predictions</code> from the repository root
          to regenerate it.
        </ErrorState>
      )}

      {status === 'ready' && (
        <Suspense fallback={<Loading label="Loading page" />}>
          <Routes>
            <Route path="/" element={<Overview />} />
            <Route path="/trip" element={<SmartTrip />} />
            <Route path="/map" element={<LiveMap />} />
            <Route path="/forecast" element={<Forecast />} />
            <Route path="/replay" element={<EventReplay />} />
            <Route path="/model" element={<ModelLab />} />
            <Route path="/system" element={<DataSystem />} />
            <Route path="*" element={<NotFound />} />
          </Routes>
        </Suspense>
      )}
    </Shell>
  );
}
